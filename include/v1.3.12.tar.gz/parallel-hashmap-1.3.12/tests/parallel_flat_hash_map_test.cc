#define THIS_HASH_MAP  parallel_flat_hash_map
#define THIS_TEST_NAME ParallelFlatHashMap

#include "parallel_hash_map_test.cc"
