#define THIS_HASH_MAP  parallel_node_hash_map
#define THIS_TEST_NAME ParallelNodeHashMap

#include "parallel_hash_map_test.cc"
