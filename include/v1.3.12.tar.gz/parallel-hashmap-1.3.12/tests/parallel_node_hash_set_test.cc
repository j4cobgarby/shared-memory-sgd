#define THIS_HASH_SET  parallel_node_hash_set
#define THIS_TEST_NAME ParallelNodeHashSet

#include "node_hash_set_test.cc"
