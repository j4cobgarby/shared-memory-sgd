### abs

```
number abs(number value)
```

Returns the absolute value of a number.

It is a type error if the provided argument is not a number.

### Examples


