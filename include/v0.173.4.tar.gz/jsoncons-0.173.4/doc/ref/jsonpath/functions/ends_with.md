### ends_with

```
boolean ends_with(string source, string suffix)
```

Returns true if the source string ends with the suffix string, otherwise false.

It is a type error if 

- the provided source is not a string, or

- the provided suffix is not a string

### Examples


