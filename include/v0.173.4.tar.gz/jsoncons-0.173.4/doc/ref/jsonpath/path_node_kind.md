### jsoncons::jsonpath::path_node_kind

```cpp
enum class result_options {
   root,
   name,
   index
};                             (since 0.172.0)
```

Indicates the kind of path node
                            

