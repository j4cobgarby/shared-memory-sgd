### jsoncons::json_object_arg_t 

```cpp
#include <jsoncons/tag_type.hpp>

struct json_object_arg_t {explicit json_object_arg_t() = default;};
```

`json_object_arg_t` is an empty class type used to disambiguate constructor overloads for json objects.

### See also

[json_object_arg](json_object_arg.md)
