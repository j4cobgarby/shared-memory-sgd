### jsoncons::float_chars_format

```cpp
#include <jsoncons/json_options.hpp>

enum class float_chars_format : uint8_t {general,fixed,scientific,hex};
```

A type used to specify floating-point formatting. 

