### jsoncons::byte_string_arg_t 

```cpp
#include <jsoncons/tag_type.hpp>

struct byte_string_arg_t {explicit byte_string_arg_t() = default;};
```

`byte_string_arg_t` is an empty class type used to disambiguate constructor overloads for byte strings.

### See also

[byte_string_arg](byte_string_arg.md)
