# Roadmap

### Soon

Version 1.0.0 
(we've been leading up to this since 2013.)

### Post 1.0.0

- Implement [Concise data definition language (CDDL)](https://tools.ietf.org/html/draft-ietf-cbor-cddl-08) for validating JSON and JSON-like binary formats

- Support more error recovery and introduce optional `lenient_error_handler`.

